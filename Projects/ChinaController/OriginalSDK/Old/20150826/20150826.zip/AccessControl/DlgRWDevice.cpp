// DlgRWDevice.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "AccessControl.h"
#include "DlgRWDevice.h"


// CDlgRWDevice �Ի���

IMPLEMENT_DYNAMIC(CDlgRWDevice, CDialog)

CDlgRWDevice::CDlgRWDevice(CWnd* pParent /*=NULL*/, LLONG hLoginID , NET_DEVICE_TYPE emDevType)
	: CDialog(CDlgRWDevice::IDD, pParent)
{

	m_hLoginID = hLoginID;
	m_emDevType = emDevType;
}

CDlgRWDevice::~CDlgRWDevice()
{
}

void CDlgRWDevice::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX); 
	DDX_Control(pDX, IDC_DLG_RW_EDT_DATA, m_deviceData);
}


BEGIN_MESSAGE_MAP(CDlgRWDevice, CDialog)
	ON_BN_CLICKED(IDC_DLG_RW_BTN_READ, &CDlgRWDevice::OnBnClickedDlgRwBtnRead)
	ON_BN_CLICKED(IDC_DLG_RW_BTN_WRITE, &CDlgRWDevice::OnBnClickedDlgRwBtnWrite)
	ON_EN_CHANGE(IDC_DLG_RW_EDT_DATA, &CDlgRWDevice::OnEnChangeDlgRwEdtData)
END_MESSAGE_MAP()


// CDlgRWDevice ��Ϣ��������


BOOL CDlgRWDevice::OnInitDialog() 
{
	CDialog::OnInitDialog();

	// TODO: Add extra initialization here
	g_SetWndStaticText(this, DLG_CFG_RWDATA);

	InitDlg();
	//OnQuerylogBtnTotalCount();
	// TODO: Add your control notification handler code here
	

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}


void CDlgRWDevice::InitDlg()
{ 
	m_deviceData.Clear();
	GetDlgItem(IDC_DLG_RW_BTN_WRITE)->EnableWindow(FALSE); 
}
void CDlgRWDevice::OnBnClickedDlgRwBtnRead()
{
	ReadRefactored();
}

void CDlgRWDevice::ReadNative()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (!m_hLoginID)
	{
		MessageBox(ConvertString(CString("we haven't login a device yet!"), DLG_VERSION), ConvertString("Prompt"));
		return;

	}

	memset(&m_stuInfo,0,sizeof(CFG_CLIENT_CUSTOM_INFO));  
	CString csReadPos;
	GetDlgItemText(IDC_DLG_RW_EDT_STARTPOS, csReadPos);

	 
	char szJsonBuf[1024 * 40] = {0};
	int nerror = 0;
	BOOL bRet = CLIENT_GetNewDevConfig(m_hLoginID, CFG_CMD_CLIENT_CUSTOM_DATA, -1, szJsonBuf, 1024 *40, &nerror, 5000);

	if (bRet)
	{
		GetDlgItem(IDC_DLG_RW_BTN_WRITE)->EnableWindow(TRUE); 
		DWORD dwRetLen = 0;
		bRet = CLIENT_ParseData(CFG_CMD_CLIENT_CUSTOM_DATA, szJsonBuf, (void*)&m_stuInfo, sizeof(m_stuInfo), &dwRetLen);
		if (!bRet)
		{
			MessageBox(ConvertString(CString("parse AccessControl error..."), DLG_CFG_ACCESS_CONTROL), ConvertString("Prompt"));
			return  ;
		}else
		{
			if (m_stuInfo.abBinary)
			{
 
				CString csBinaryValue; 
				for (int i = 0; i < m_stuInfo.nBinaryNum; i++)
				{
					CString cstValue;
					cstValue.Format("%d ", m_stuInfo.dwBinary[i]) ;
					csBinaryValue += cstValue ;
				}
				SetDlgItemText(IDC_DLG_RW_EDT_DATA, csBinaryValue);  
				//UpdateWindow();
			}

		}
	}
	else
	{			
		CString csErr;
		csErr.Format("%s 0x%08x...\r\n\r\n%s", ConvertString("QueryConfig AccessControl error:", DLG_CFG_ACCESS_CONTROL),
			CLIENT_GetLastError(), szJsonBuf);
		MessageBox(csErr, ConvertString("Prompt"));
		return  ;
	}
	return  ;
}

void CDlgRWDevice::ReadRefactored()
{

	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (!m_hLoginID)
	{
		MessageBox(ConvertString(CString("we haven't login a device yet!"), DLG_VERSION), ConvertString("Prompt"));
		return;

	}

	memset(&m_stuInfo,0,sizeof(CFG_CLIENT_CUSTOM_INFO));  
	CString csReadPos;
	GetDlgItemText(IDC_DLG_RW_EDT_STARTPOS, csReadPos);

	 
	char szJsonBuf[1024 * 40] = {0};
	int nerror = 0;
	BOOL bRet = CLIENT_GetNewDevConfig(m_hLoginID, CFG_CMD_CLIENT_CUSTOM_DATA, -1, szJsonBuf, 1024 *40, &nerror, 5000);

	if (bRet)
	{
		GetDlgItem(IDC_DLG_RW_BTN_WRITE)->EnableWindow(TRUE); 
		DWORD dwRetLen = 0;
		bRet = CLIENT_ParseData(CFG_CMD_CLIENT_CUSTOM_DATA, szJsonBuf, (void*)&m_stuInfo, sizeof(m_stuInfo), &dwRetLen);
		if (!bRet)
		{
			MessageBox(ConvertString(CString("parse AccessControl error..."), DLG_CFG_ACCESS_CONTROL), ConvertString("Prompt"));
			return  ;
		}
		else
		{
			if (m_stuInfo.abBinary)
			{
 				CString csBinaryValue; 
				for (int i = 0; i < m_stuInfo.nBinaryNum; i++)
				{
					CString cstValue;
					cstValue = (char)m_stuInfo.dwBinary[i];
					csBinaryValue += cstValue ;
				}
				SetDlgItemText(IDC_DLG_RW_EDT_DATA, csBinaryValue);  
				//UpdateWindow();
			}

		}
	}
	else
	{			
		CString csErr;
		csErr.Format("%s 0x%08x...\r\n\r\n%s", ConvertString("QueryConfig AccessControl error:", DLG_CFG_ACCESS_CONTROL),
			CLIENT_GetLastError(), szJsonBuf);
		MessageBox(csErr, ConvertString("Prompt"));
		return  ;
	}
	return  ;
}

void CDlgRWDevice::OnBnClickedDlgRwBtnWrite()
{
	WriteRefactored();
}

void CDlgRWDevice::WriteNative()
{
	// TODO: �ڴ����ӿؼ�֪ͨ����������� 
	if (!m_hLoginID)
	{
		MessageBox(ConvertString(CString("we haven't login a device yet!"), DLG_VERSION), ConvertString("Prompt"));

	} 
		int nerror = 0;
		int nChannel = -1;

		CString csBinaryValue; 
		GetDlgItemText(IDC_DLG_RW_EDT_DATA, csBinaryValue); 
		int iPos = 0;
		CString csIntValue;
		int iNumber = 0;
		csIntValue = csBinaryValue.Tokenize(" ", iPos);
		while (csIntValue != "")
		{ 
			int IntValue = _tstoi(csIntValue);
			m_stuInfo.dwBinary[iNumber] = IntValue;
			iNumber ++;
			csIntValue = csBinaryValue.Tokenize(" ", iPos);
			if (iNumber > 127)
			{
				csIntValue = "";
				iNumber = 128;
				break;
			}
		}
		// �޸Ĳ�����������
		m_stuInfo.abBinary = true;
		m_stuInfo.nBinaryNum = iNumber; 

		char szJsonBufSet[1024 * 40] = {0};            

		BOOL bRet = CLIENT_PacketData(CFG_CMD_CLIENT_CUSTOM_DATA, &m_stuInfo, sizeof(m_stuInfo), szJsonBufSet, sizeof(szJsonBufSet));
		if (!bRet)
		{
			MessageBox(ConvertString(CString("Packet ClientCustomData Config failed!"), DLG_CFG_ACCESS_CONTROL), ConvertString("Prompt"));
		} 
		else
		{ 
			 
			int nerror = 0;
			int nrestart = 0;
			bRet = CLIENT_SetNewDevConfig(m_hLoginID, CFG_CMD_CLIENT_CUSTOM_DATA, nChannel, szJsonBufSet, sizeof(szJsonBufSet), &nerror, &nrestart, SDK_API_WAITTIME);
			if (!bRet)
			{
				//printf("Set ClientCustomData Config failed...0x%08x\n", CLIENT_GetLastError());
				MessageBox(ConvertString(CString("Set ClientCustomData Config failed\n"), DLG_CFG_ACCESS_CONTROL), ConvertString("Prompt"));
			}
			else
			{
				MessageBox(ConvertString(CString("Set ClientCustomData Config ok!\n"), DLG_CFG_ACCESS_CONTROL), ConvertString("Prompt"));
			}
		} 
}

void CDlgRWDevice::WriteRefactored()
{
	if (!m_hLoginID)
	{
		MessageBox(ConvertString(CString("we haven't login a device yet!"), DLG_VERSION), ConvertString("Prompt"));

	} 
		int nerror = 0;
		int nChannel = -1;

		CString csBinaryValue; 
		GetDlgItemText(IDC_DLG_RW_EDT_DATA, csBinaryValue); 
		int strLength = csBinaryValue.GetLength();
		memset(&m_stuInfo, 0, sizeof(m_stuInfo));
		for (int i = 0; i < strLength; i++)
		{ 
			int asciiValue = csBinaryValue.GetAt(i);
			m_stuInfo.dwBinary[i] = asciiValue;
		}
		m_stuInfo.abBinary = true;
		m_stuInfo.nBinaryNum = strLength; 

		char szJsonBufSet[1024 * 40] = {0};            

		BOOL bRet = CLIENT_PacketData(CFG_CMD_CLIENT_CUSTOM_DATA, &m_stuInfo, sizeof(m_stuInfo), szJsonBufSet, sizeof(szJsonBufSet));
		if (!bRet)
		{
			MessageBox(ConvertString(CString("Packet ClientCustomData Config failed!"), DLG_CFG_ACCESS_CONTROL), ConvertString("Prompt"));
		} 
		else
		{ 
			 
			int nerror = 0;
			int nrestart = 0;
			bRet = CLIENT_SetNewDevConfig(m_hLoginID, CFG_CMD_CLIENT_CUSTOM_DATA, nChannel, szJsonBufSet, sizeof(szJsonBufSet), &nerror, &nrestart, SDK_API_WAITTIME);
			if (!bRet)
			{
				//printf("Set ClientCustomData Config failed...0x%08x\n", CLIENT_GetLastError());
				MessageBox(ConvertString(CString("Set ClientCustomData Config failed\n"), DLG_CFG_ACCESS_CONTROL), ConvertString("Prompt"));
			}
			else
			{
				MessageBox(ConvertString(CString("Set ClientCustomData Config ok!\n"), DLG_CFG_ACCESS_CONTROL), ConvertString("Prompt"));
			}
		} 
}

void CDlgRWDevice::OnDestroy() 
{
	CDialog::OnDestroy();
 
 
}
void CDlgRWDevice::OnEnChangeDlgRwEdtData()
{
	// TODO:  ����ÿؼ��� RICHEDIT �ؼ�������������
	// ���͸�֪ͨ��������д CDialog::OnInitDialog()
	// ���������� CRichEditCtrl().SetEventMask()��
	// ͬʱ�� ENM_CHANGE ��־�������㵽�����С�

	// TODO:  �ڴ����ӿؼ�֪ͨ�����������

	//CString csBinaryValue; 
	//GetDlgItemText(IDC_DLG_RW_EDT_DATA, csBinaryValue); 

}
